AIO_FEEDS_ID = ["bedroom-light", "bedroom-smoke", "bedroom-speaker", "bedroom-temp", "hall-infrared", "hall-light"]
AIO_USERNAME = "huynhngoctan"
AIO_KEY = "aio_aDGa39h5QCfbXkEdJ1fLiCfsLewa"