package com.quintus.labs.smarthome.ui.activity;

import android.os.Build;
import android.util.Log;

import com.hivemq.client.mqtt.MqttClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5BlockingClient;

import java.util.concurrent.atomic.AtomicBoolean;

import androidx.annotation.RequiresApi;

import static com.hivemq.client.mqtt.MqttGlobalPublishFilter.ALL;
import static java.nio.charset.StandardCharsets.UTF_8;

public class HiveMQTTHelper {

    public Mqtt5BlockingClient client;

    private final String host = "9ffce779bd4242b79eeee549796af5c7.s1.eu.hivemq.cloud";
    private final String username = "lionelnhat26";
    private final String password = "01679505953aaB";


    public HiveMQTTHelper(){
        //create an MQTT client
        client = MqttClient.builder()
            .useMqttVersion5()
            .serverHost(host)
            .serverPort(8883)
            .sslWithDefaultConfig()
            .buildBlocking();

        //connect to HiveMQ Cloud with TLS and username/pw
        client.connectWith()
            .simpleAuth()
            .username(username)
            .password(UTF_8.encode(password))
            .applySimpleAuth()
            .send();

        Log.d("a", "Connected HiveMQTT successfully");
    }

    public void subscribeWithTopic(String topic){
        client.subscribeWith()
            .topicFilter(topic)
            .send();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void publishMessageTopic(String topic, String payload){
        //publish a message to the topic
        client.publishWith()
            .topic(topic)
            .payload(UTF_8.encode(payload))
            .send();
    }
}
