package com.quintus.labs.smarthome.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.TransitionDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ToggleButton;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.quintus.labs.smarthome.R;
import com.quintus.labs.smarthome.adapter.SingleRoomAdapter;
import com.quintus.labs.smarthome.model.Room;
import com.quintus.labs.smarthome.utils.SwitchButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import static com.hivemq.client.mqtt.MqttGlobalPublishFilter.ALL;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Smart Home
 * https://github.com/quintuslabs/SmartHome
 * Created on 27-OCT-2019.
 * Created by : Santosh Kumar Dash:- http://santoshdash.epizy.com
 */
public class RoomDetailsActivity extends AppCompatActivity {
    MQTTHelper mqttHelper;
    HiveMQTTHelper hiveMQTTHelper;

    private List<Room> roomList = new ArrayList<>();
    private RecyclerView recyclerView;
    private SingleRoomAdapter mAdapter;
    private TextView roomName;
    private ImageView imageViewLeft;
    private TextView textLeft;
    private ImageView imageViewRight;
    private TextView textRight;

    private TextView leftNumber;
    private TextView rightNumber;
    private MediaPlayer mp;


    public static void setWindowFlag(Activity activity, final int bits, boolean on) {

        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle bundle = getIntent().getExtras();
        String room_name = "";
        if(bundle != null){
            room_name = bundle.getString("room_name");
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        //make fully Android Transparent Status bar
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_details);

        hiveMQTTHelper = new HiveMQTTHelper();

        mp = MediaPlayer.create(getApplicationContext(), R.raw.baochay);
        mp.setLooping(true);


        recyclerView = findViewById(R.id.recycler_view);
        roomName = findViewById(R.id.room_name);
        imageViewLeft = findViewById(R.id.image_view_left);
        imageViewRight = findViewById(R.id.image_view_right);
        textLeft = findViewById(R.id.text_left);
        textRight = findViewById(R.id.text_right);
        leftNumber = findViewById(R.id.left_number);
        rightNumber = findViewById(R.id.right_number);
        roomName.setText(room_name);


        mAdapter = new SingleRoomAdapter(roomList, room_name, getApplicationContext());
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        prepareRoomData(room_name);
        startMQTT();

    }

    private void prepareRoomData(String room_name) {
        Room room;
        switch (room_name){
            case "Bed Room":
                imageViewRight.setBackgroundResource(R.drawable.ic_smoke);
                getLastSensorValue("bedroom-temp");
                getLastSensorValue("bedroom-smoke");
                room = new Room("1", "Light");
                roomList.add(room);
                mAdapter.notifyDataSetChanged();
                break;
            case "Kitchen":
                room = new Room("1", "Light");
                roomList.add(room);
                room = new Room("2", "Fan");
                roomList.add(room);
                room = new Room("1", "Air Conditioner");
                roomList.add(room);
                room = new Room("2", "Microwave");
                roomList.add(room);
                room = new Room("1", "Speaker");
                roomList.add(room);
                mAdapter.notifyDataSetChanged();
                break;
            case "Dining Room":
                room = new Room("1", "Light");
                roomList.add(room);
                room = new Room("2", "Fan");
                roomList.add(room);
                room = new Room("1", "Air Conditioner");
                roomList.add(room);
                room = new Room("2", "TV");
                roomList.add(room);
                mAdapter.notifyDataSetChanged();
                break;
            case "Living Room":
                room = new Room("1", "Light");
                roomList.add(room);
                room = new Room("2", "Fan");
                roomList.add(room);
                room = new Room("1", "Air Conditioner");
                roomList.add(room);
                room = new Room("2", "TV");
                roomList.add(room);
                room = new Room("1", "Speaker");
                roomList.add(room);
                mAdapter.notifyDataSetChanged();
                break;
            case "Hall":
                getLastSensorValue("hall-light");
                getLastSensorValue("hall-infrared");
                imageViewLeft.setBackgroundResource(R.drawable.lightsensor);
                imageViewRight.setBackgroundResource(R.drawable.ic_profile_user);
                textLeft.setText("LIGHT SENSOR");
                textRight.setText("PERSON");

                room = new Room("1", "Light");
                roomList.add(room);
                mAdapter.notifyDataSetChanged();
                break;
        }

    }

    public void onBackClicked(View view) {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }

    private void sendDataToMQTT(String topic, String mess){

        MqttMessage msg = new MqttMessage();
        msg.setId(1234);
        msg.setQos(0);
        msg.setRetained(true);

        byte[] b = mess.getBytes(Charset.forName("UTF-8"));
        msg.setPayload(b);

        try {
            mqttHelper.mqttAndroidClient.publish(topic, msg);
        }catch (Exception e){}

    }
    private void startMQTT(){
        mqttHelper = new MQTTHelper(getApplicationContext(), "1234567");

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                if(topic.contains("bedroom-temp")){
                    Log.d("Mqtt", "Received Bedroom Temp: " + message.toString());
                    leftNumber.setText(message.toString()+"\u2103");
                }
                if(topic.contains("bedroom-smoke")){
                    Log.d("Mqtt", "Received Bedroom Smoke: " + message.toString());
                    rightNumber.setText(message.toString()+"%");
                    if(Integer.parseInt(message.toString()) != 0){
                        sendDataToMQTT("huynhngoctan/feeds/bedroom-speaker", "1");
                        textRight.setText("Detect Smoke");
                        mp.start();
                    }
                    else{
                        sendDataToMQTT("huynhngoctan/feeds/bedroom-speaker", "0");
                        textRight.setText("No Detect");
                        mp.pause();
                    }
                }

                if(topic.contains("hall-light")){
                    Log.d("Mqtt", "Received Hall Light: " + message.toString());
                    leftNumber.setText(message.toString()+"cd");
                    if(Float.parseFloat(message.toString()) <= 100 && rightNumber.getText().equals("Yes")){
                        hiveMQTTHelper.publishMessageTopic("topic/bolb","1");
                    }
                    else{
                        hiveMQTTHelper.publishMessageTopic("topic/bolb","0");
                    }
                }

                if(topic.contains("hall-infrared")){
                    Log.d("Mqtt", "Received Hall Infrared: " + message.toString());

                    String result = message.toString().equals("1")  ? "Yes":"No";

                    rightNumber.setText(result);
                    if(Float.parseFloat(leftNumber.getText().subSequence(0, leftNumber.getText().length()-2).toString()) <= 100 && rightNumber.getText().equals("Yes")){
                        hiveMQTTHelper.publishMessageTopic("topic/bolb","1");
                    }
                    else{
                        hiveMQTTHelper.publishMessageTopic("topic/bolb","0");
                    }

                }

            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }

            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d("Mqtt", "Kết nối thành công");
            }
        });
    }

    private void getLastSensorValue(String topic){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+topic+"/data/retain";
        StringRequest strRequest;
        switch(topic){
            case "bedroom-temp":
                strRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String responseTemp) {
                            leftNumber.setText(responseTemp.split(",")[0]+"\u2103");
                        }
                    }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
            case "bedroom-smoke":
                strRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            rightNumber.setText(response.split(",")[0]+"%");
                            if(response.split(",")[0].equals("0")){
                                textRight.setText("No Detect");
                            }
                            else{
                                textRight.setText("Detect Smoke");
                            }
                        }
                    }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
            case "hall-light":
                strRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            leftNumber.setText(response.split(",")[0]+"cd");
                        }
                    }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
            case "hall-infrared":
                strRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            rightNumber.setText(response.split(",")[0].equals("1")?"Yes":"No");
                        }
                    }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
        }
    }

}
