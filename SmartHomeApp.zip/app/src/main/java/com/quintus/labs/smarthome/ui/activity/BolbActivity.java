package com.quintus.labs.smarthome.ui.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.TransitionDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.quintus.labs.smarthome.R;
import com.quintus.labs.smarthome.utils.SwitchButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import static com.hivemq.client.mqtt.MqttGlobalPublishFilter.ALL;
import static java.nio.charset.StandardCharsets.UTF_8;

public class BolbActivity extends AppCompatActivity {

    HiveMQTTHelper hiveMQTTHelper;
    MQTTHelper mqttHelper;

    private TextView roomName;
    private ImageView imageViewLeft;
    private TextView textLeft;
    private ImageView imageViewRight;
    private TextView textRight;

    private TextView leftNumber;
    private TextView rightNumber;

    private boolean isTurnOn;

    SwitchButton btnAuto;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    private FirebaseAuth mAuth;

    ToggleButton button;

    ImageView image;

    TransitionDrawable drawable;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle bundle = getIntent().getExtras();
        String room_name = "";
        if(bundle != null){
            room_name = bundle.getString("room_name");
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bolb);
        button = (ToggleButton)findViewById(R.id.button);

        image = (ImageView)findViewById(R.id.image);
        drawable = (TransitionDrawable)image.getDrawable();

        mAuth = FirebaseAuth.getInstance();

        roomName = findViewById(R.id.room_name);
        imageViewLeft = findViewById(R.id.image_view_left);
        imageViewRight = findViewById(R.id.image_view_right);
        textLeft = findViewById(R.id.text_left);
        textRight = findViewById(R.id.text_right);
        leftNumber = findViewById(R.id.left_number);
        rightNumber = findViewById(R.id.right_number);
        btnAuto = findViewById(R.id.auto);
        roomName.setText(room_name);

        textLeft.setText("LIGHT SENSOR");
        textRight.setText("PERSON");
        imageViewLeft.setBackgroundResource(R.drawable.lightsensor);
        imageViewRight.setBackgroundResource(R.drawable.ic_profile_user);

        getLastSensorValue("hall-light");
        getLastSensorValue("hall-infrared");

        DocumentReference docRef = db.collection("HallLight").document("0");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        String state = document.getData().get("state").toString();
                        if(state.equals("1")){
                            drawable.startTransition(1000);
                            button.setChecked(true);
                            isTurnOn = true;
                        }
                        else{
                            button.setChecked(false);
                            isTurnOn = false;
                        }
                    }
                }
            }
        });

        button.setVisibility(!btnAuto.isChecked() ? View.VISIBLE : View.INVISIBLE);

        btnAuto.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                button.setVisibility(!btnAuto.isChecked() ? View.VISIBLE : View.INVISIBLE);
                button.setEnabled(!btnAuto.isChecked());
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {
                db.collection("Users").document("0").delete();
                Map<String, Object> data = new HashMap<>();
                if(button.isChecked()){
                    hiveMQTTHelper.publishMessageTopic("topic/bolb","1");
                    data.put("state", "1");
                }
                else{
                    hiveMQTTHelper.publishMessageTopic("topic/bolb","0");
                    data.put("state", "0");
                }
                db.collection("HallLight").document("0")
                    .set(data, SetOptions.merge());
            }
        });


        startHiveMQTT();
        startMQTT();

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void startHiveMQTT(){
        hiveMQTTHelper = new HiveMQTTHelper();

        hiveMQTTHelper.subscribeWithTopic("topic/bolb");


        //set a callback that is called when a message is received (using the async API style)
        hiveMQTTHelper.client.toAsync().publishes(ALL, publish -> {

            String message = UTF_8.decode(publish.getPayload().get()).toString();

            Log.d("a", "Received message: " + publish.getTopic() + " -> " + message);

            if(message.equals("0")){
                if(isTurnOn) {
                    drawable.reverseTransition(1000);
                    isTurnOn = false;
                }
            }
            else{
                if(!isTurnOn){
                    drawable.startTransition(1000);
                    isTurnOn = true;
                }
            }
        });
    }

    private void startMQTT(){
        mqttHelper = new MQTTHelper(getApplicationContext(), "1234567");

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {

                if(topic.contains("hall-light")){
                    Log.d("Mqtt", "Received Hall Light: " + message.toString());
                    leftNumber.setText(message.toString()+"cd");
                    if(btnAuto.isChecked()){
                        db.collection("HallLight").document("0").delete();
                        Map<String, Object> data = new HashMap<>();
                        if(Float.parseFloat(message.toString()) <= 100 && rightNumber.getText().equals("Yes")){
                            if(!isTurnOn) {
                                hiveMQTTHelper.publishMessageTopic("topic/bolb", "1");
                                button.setChecked(true);
                                data.put("state", "1");
                            }
                        }
                        else{
                            if(isTurnOn){
                                hiveMQTTHelper.publishMessageTopic("topic/bolb","0");
                                button.setChecked(false);
                                data.put("state", "0");
                            }
                        }
                        db.collection("HallLight").document("0")
                            .set(data, SetOptions.merge());
                    }
                }

                if(topic.contains("hall-infrared")){
                    Log.d("Mqtt", "Received Hall Infrared: " + message.toString());

                    String result = message.toString().equals("1")  ? "Yes":"No";

                    rightNumber.setText(result);
                    if(btnAuto.isChecked()){
                        db.collection("HallLight").document("0").delete();
                        Map<String, Object> data = new HashMap<>();
                        if(Float.parseFloat(leftNumber.getText().subSequence(0, leftNumber.getText().length()-2).toString()) <= 100 && rightNumber.getText().equals("Yes")){
                            if(!isTurnOn){
                                hiveMQTTHelper.publishMessageTopic("topic/bolb","1");
                                button.setChecked(true);
                                data.put("state", "1");
                            }
                        }
                        else{
                            if(isTurnOn){
                                hiveMQTTHelper.publishMessageTopic("topic/bolb","0");
                                button.setChecked(false);
                                data.put("state", "0");
                            }
                        }
                        db.collection("HallLight").document("0")
                            .set(data, SetOptions.merge());
                    }

                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }

            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d("Mqtt", "Kết nối thành công");
            }
        });
    }

    private void getLastSensorValue(String topic){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+topic+"/data/retain";
        StringRequest strRequest;
        switch(topic){
            case "hall-light":
                strRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                leftNumber.setText(response.split(",")[0]+"cd");
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
            case "hall-infrared":
                strRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                rightNumber.setText(response.split(",")[0].equals("1")?"Yes":"No");
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });
                queue.add(strRequest);
                break;
        }
    }
}
