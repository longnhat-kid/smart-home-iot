package com.quintus.labs.smarthome.ui.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.quintus.labs.smarthome.R;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    EditText personName;
    EditText userName;
    EditText passWord;
    TextView clearInput;

    private FirebaseAuth mAuth;

    private FirebaseFirestore db;

    public static void setWindowFlag(Activity activity, final int bits, boolean on) {

        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        //make fully Android Transparent Status bar
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        personName = findViewById(R.id.person_name);
        userName = findViewById(R.id.user_name);
        passWord = findViewById(R.id.password);

        clearInput = findViewById(R.id.clear_input);
        clearInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                personName.setText("");
                userName.setText("");
                passWord.setText("");
                personName.requestFocus();
            }
        });

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

    }

    public void onRegisterClicked(View view) {
        final String strPersonName = personName.getText().toString();
        final String strUserName = userName.getText().toString();
        final String strPassWord = passWord.getText().toString();

        if(strPersonName.length()==0)
        {
            personName.requestFocus();
            personName.setError("Person name cannot be empty");
        }
        if(strUserName.length()==0)
        {
            userName.requestFocus();
            userName.setError("Username cannot be empty");
        }
        if(strPassWord.length()==0)
        {
            passWord.requestFocus();
            passWord.setError("Password cannot be empty");
        }
        else if(!strPersonName.matches("[a-zA-Z ]+"))
        {
            personName.requestFocus();
            personName.setError("Enter Only Alphabetical Character");
        }
        else if(strPassWord.length() < 6)
        {
            passWord.requestFocus();
            passWord.setError("Password cannot be less than 6 characters");
        }
        else
        {
            mAuth.createUserWithEmailAndPassword(strUserName, strPassWord)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Signup", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            Map<String, Object> data = new HashMap<>();
                            data.put("personName", strPersonName);

                            db.collection("Users").document(user.getUid())
                                    .set(data, SetOptions.merge());
                            Toast.makeText(RegisterActivity.this,"Register Account Successfully !!",Toast.LENGTH_LONG).show();
                            Bundle bundle = new Bundle();
                            bundle.putString("user_display_name", strPersonName);
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            intent.putExtras(bundle);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("Signup", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(RegisterActivity.this, "Register Account Failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        }
    }
}