package com.quintus.labs.smarthome.adapter;


import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.TransitionDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.quintus.labs.smarthome.R;
import com.quintus.labs.smarthome.model.Room;
import com.quintus.labs.smarthome.ui.activity.BolbActivity;
import com.quintus.labs.smarthome.ui.activity.HiveMQTTHelper;
import com.quintus.labs.smarthome.ui.activity.MQTTHelper;
import com.quintus.labs.smarthome.ui.activity.MainActivity;
import com.quintus.labs.smarthome.ui.activity.RoomDetailsActivity;
import com.quintus.labs.smarthome.utils.SwitchButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.hivemq.client.mqtt.MqttGlobalPublishFilter.ALL;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Smart Home
 * https://github.com/quintuslabs/SmartHome
 * Created on 27-OCT-2019.
 * Created by : Santosh Kumar Dash:- http://santoshdash.epizy.com
 */

public class SingleRoomAdapter extends RecyclerView.Adapter<SingleRoomAdapter.MyViewHolder> {

    MQTTHelper mqttHelper;
    HiveMQTTHelper hiveMQTTHelper;
    Context context;
    private List<Room> roomList;
    String roomName;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    public SingleRoomAdapter(List<Room> roomList, String roomName, Context context) {
        this.roomList = roomList;
        this.context = context;
        this.roomName = roomName.replace(" ","").toLowerCase(Locale.ROOT);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_room_row, parent, false);

        return new MyViewHolder(itemView);
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        Room room = roomList.get(position);

        holder.title.setText(room.getName());

        mqttHelper = new MQTTHelper(context, "1234567");

        hiveMQTTHelper = new HiveMQTTHelper();

        hiveMQTTHelper.subscribeWithTopic("topic/bolb");


        switch (room.getName()){
            case "Light":
                // Instantiate the RequestQueue.
                RequestQueue queue = Volley.newRequestQueue(context);
                String urlLight ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+roomName+"-light"+"/data/retain";

                StringRequest stringRequestLight = new StringRequest(Request.Method.GET, urlLight,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.split(",")[0].equals("1")){
                                    holder.button.setChecked(false);
                                }
                                else{
                                    holder.button.setChecked(true);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });

                queue.add(stringRequestLight);

                holder.button.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                        if(isChecked){
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-light", "0");
                            Log.d("test", "huynhngoctan/feeds/" + roomName +"-light");
                        }
                        else{
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-light", "1");
                        }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectionLost(Throwable cause) {

                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws Exception {

                        if(topic.contains(roomName+"-light")){
                            if(message.toString().equals("1")){
                                holder.button.setChecked(false);
                            }
                            else{
                                holder.button.setChecked(true);
                            }
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {

                    }

                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.d("Mqtt", "Kết nối thành công");
                    }
                });
                holder.imageView.setBackgroundResource(R.drawable.light);
                break;
            case "Fan":
                // Instantiate the RequestQueue.
                RequestQueue queueFan = Volley.newRequestQueue(context);
                String urlFan ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+roomName+"-fan"+"/data/retain";

                StringRequest stringRequestFan = new StringRequest(Request.Method.GET, urlFan,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.split(",")[0].equals("1")){
                                    holder.button.setChecked(false);
                                }
                                else{
                                    holder.button.setChecked(true);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });

                queueFan.add(stringRequestFan);

                holder.button.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                        if(isChecked){
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-fan", "0");
                            Log.d("test", "huynhngoctan/feeds/" + roomName +"-fan");
                        }
                        else{
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-fan", "1");
                        }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectionLost(Throwable cause) {

                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws Exception {

                        if(topic.contains(roomName+"-fan")){
                            if(message.toString().equals("1")){
                                holder.button.setChecked(false);
                            }
                            else{
                                holder.button.setChecked(true);
                            }
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {

                    }

                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.d("Mqtt", "Kết nối thành công");
                    }
                });
                holder.imageView.setBackgroundResource(R.drawable.fan);
                break;
            case "Air Conditioner":
                // Instantiate the RequestQueue.
                RequestQueue queueAir = Volley.newRequestQueue(context);
                String urlAir ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+roomName+"-air"+"/data/retain";

                StringRequest stringRequestAir = new StringRequest(Request.Method.GET, urlAir,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.split(",")[0].equals("1")){
                                    holder.button.setChecked(false);
                                }
                                else{
                                    holder.button.setChecked(true);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });

                queueAir.add(stringRequestAir);

                holder.button.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                        if(isChecked){
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-air", "0");
                            Log.d("test", "huynhngoctan/feeds/" + roomName +"-air");
                        }
                        else{
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-air", "1");
                        }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectionLost(Throwable cause) {

                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws Exception {

                        if(topic.contains(roomName+"-air")){
                            if(message.toString().equals("1")){
                                holder.button.setChecked(false);
                            }
                            else{
                                holder.button.setChecked(true);
                            }
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {

                    }

                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.d("Mqtt", "Kết nối thành công");
                    }
                });
                holder.imageView.setBackgroundResource(R.drawable.air_conditioner);
                break;
            case "Table Light":
                // Instantiate the RequestQueue.
                RequestQueue queueTable = Volley.newRequestQueue(context);
                String urlTable ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+roomName+"-tlight"+"/data/retain";

                StringRequest stringRequestTable = new StringRequest(Request.Method.GET, urlTable,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.split(",")[0].equals("1")){
                                    holder.button.setChecked(false);
                                }
                                else{
                                    holder.button.setChecked(true);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });

                queueTable.add(stringRequestTable);

                holder.button.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                        if(isChecked){
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-tlight", "0");
                            Log.d("test", "huynhngoctan/feeds/" + roomName +"-tlight");
                        }
                        else{
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-tlight", "1");
                        }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectionLost(Throwable cause) {

                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws Exception {

                        if(topic.contains(roomName+"-tlight")){
                            if(message.toString().equals("1")){
                                holder.button.setChecked(false);
                            }
                            else{
                                holder.button.setChecked(true);
                            }
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {

                    }

                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.d("Mqtt", "Kết nối thành công");
                    }
                });
                holder.imageView.setBackgroundResource(R.drawable.table_light);
                break;
            case "TV":
                // Instantiate the RequestQueue.
                RequestQueue queueTv = Volley.newRequestQueue(context);
                String urlTv ="https://io.adafruit.com/api/v2/huynhngoctan/feeds/"+roomName+"-tivi"+"/data/retain";

                StringRequest stringRequestTv = new StringRequest(Request.Method.GET, urlTv,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if(response.split(",")[0].equals("1")){
                                    holder.button.setChecked(false);
                                }
                                else{
                                    holder.button.setChecked(true);
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("a", "That didn't work!");
                    }
                });

                queueTv.add(stringRequestTv);

                holder.button.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
                    public void onCheckedChanged(SwitchButton buttonView, boolean isChecked) {
                        if(isChecked){
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-tivi", "0");
                            Log.d("test", "huynhngoctan/feeds/" + roomName +"-tivi");
                        }
                        else{
                            sendDataToMQTT("huynhngoctan/feeds/" + roomName +"-tivi", "1");
                        }
                    }
                });

                mqttHelper.setCallback(new MqttCallbackExtended() {
                    @Override
                    public void connectionLost(Throwable cause) {

                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws Exception {

                        if(topic.contains(roomName+"-tivi")){
                            if(message.toString().equals("1")){
                                holder.button.setChecked(false);
                            }
                            else{
                                holder.button.setChecked(true);
                            }
                        }
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {

                    }

                    @Override
                    public void connectComplete(boolean reconnect, String serverURI) {
                        Log.d("Mqtt", "Kết nối thành công");
                    }
                });
                holder.imageView.setBackgroundResource(R.drawable.tivi);
                break;
            case "Speaker":

                holder.imageView.setBackgroundResource(R.drawable.speaker);
                break;
            case "Microwave":

                holder.imageView.setBackgroundResource(R.drawable.microwave);
                break;
        }


    }

    @Override
    public int getItemCount() {
        return roomList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public CardView cardView;
        public ImageView imageView;
        public SwitchButton button;

        public MyViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.title);
            cardView = view.findViewById(R.id.card_view);
            imageView = view.findViewById(R.id.image_view);
            button = view.findViewById(R.id.button_switch);
        }
    }


    private void sendDataToMQTT(String topic, String mess){

        MqttMessage msg = new MqttMessage();
        msg.setId(1234);
        msg.setQos(0);
        msg.setRetained(true);

        byte[] b = mess.getBytes(Charset.forName("UTF-8"));
        msg.setPayload(b);

        try {
            mqttHelper.mqttAndroidClient.publish(topic, msg);
        }catch (Exception e){}

    }
}